#include "ros/ros.h"
#include "std_msgs/Int32.h"
#include "std_msgs/String.h"

void callback(const std_msgs::Int32 data)
{
	ros::NodeHandle n;
	ros::Publisher pub = n.advertise<std_msgs::Int32>("battery_warning_light", 1000); 
	ros::Rate loop_rate(1);
	int count =0;
	std_msgs::Int32 msg;
	int value;
	if(data.data < 33)
		value = 0;
	else
		value = 1;

	msg.data = value;
	
	while (ros::ok())
 	{	
    	
    	if(count % 2 == 1)
    		msg.data = 1;
    	else
    		msg.data *= value;
    	ROS_INFO("%d", msg.data);
   		pub.publish(msg);
   		ros::spinOnce();
    	loop_rate.sleep();
    	count ++;
	}
}

int main(int argc, char *argv[])
{
	ros::init(argc, argv, "battery");
	ros::NodeHandle n1;

	ros::Subscriber sub = n1.subscribe("battery_level", 1000, callback);

	ros::spin();
	return 0;
}