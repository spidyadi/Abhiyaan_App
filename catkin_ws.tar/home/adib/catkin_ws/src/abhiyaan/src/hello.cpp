/*
	runs as rosrun test hello
	This is the publisher
*/

#include "ros/ros.h"
#include "std_msgs/String.h"
#include <sstream>

int main(int argc, char **argv)
{
  ros::init(argc, argv, "hello_cpp");
  ros::NodeHandle n;

  ros::Publisher pub = n.advertise<std_msgs::String>("random_messages", 1000); 
  // publishes to topic /random_messages and Dtype std_msgs::String
  ros::Rate loop_rate(1);

  while (ros::ok())
  {
    std_msgs::String msg;

    std::stringstream ss;
    ss << "Hello World ";
    msg.data = ss.str();


    ROS_INFO("%s", msg.data.c_str());
    pub.publish(msg);
    ros::spinOnce();
    loop_rate.sleep();
  }


  return 0;
}