#!/usr/bin/env python
import rospy
from std_msgs.msg import String

def ding(data):
	rospy.loginfo("%s", data.data)

def listener():

    rospy.init_node('hello_py', anonymous=True)
    rospy.Subscriber('random_messages', String, ding)
    rospy.spin()

if __name__ == '__main__':
    listener()